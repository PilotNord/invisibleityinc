﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

# Initialize choice tracking flags at the start of the game
default choice_nothing   = False
default choice_pity      = False
default choice_peace     = False
default choice_freedom   = False
default choice_name      = False
default choice_vengeance = False
default choice_light     = False

# Records the order the player picked things in, so the ending can
# reference whichever word was chosen last.
default choice_order = []

# Enables inline shader tags game-wide without forcing typewriter everywhere
define config.default_textshader = "typewriter"

# Explicitly map the paths inside the narrator subfolder
image narrator awe = "images/narrator/awe.png"
image narrator demonstrate = "images/narrator/demonstrate.png"
image narrator fall = "images/narrator/fall.png"
image narrator fall2 = "images/narrator/fall2.png"
image narrator fateful = "images/narrator/fateful.png"
image narrator glory = "images/narrator/glory.png"
image narrator pensive = "images/narrator/pensive.png"
image narrator ponder = "images/narrator/ponder.png"
image narrator still = "images/narrator/still.png"
image narrator wonder = "images/narrator/wonder.png"

# Transforms dark parts to deep blue and highlights to vivid cyan/blue
transform black_and_blue:
    matrixcolor TintMatrix("#2b5597") * BrightnessMatrix(-0.1)

# A deep blood-red flare, reserved for vengeance.
transform blood_red:
    matrixcolor TintMatrix("#8a1c1c") * BrightnessMatrix(-0.05)

# Restores original sprite colors and brightness
transform reset_color:
    matrixcolor TintMatrix("#ffffff") * BrightnessMatrix(0.0)

# The cave background: a warm bulb-lit pocket swallowed by dark rock.
image bg cave = "images/bg_cave.png"

# A slow, uneven brightness drift on the background
transform bulb_flicker:
    matrixcolor BrightnessMatrix(0.0)
    linear 2.6 matrixcolor BrightnessMatrix(-0.05)
    linear 1.8 matrixcolor BrightnessMatrix(0.03)
    linear 3.1 matrixcolor BrightnessMatrix(-0.08)
    linear 1.4 matrixcolor BrightnessMatrix(0.0)
    repeat

# A held, low dim for the cave, timed to the narrator's first turn blue.
transform cave_dim:
    matrixcolor BrightnessMatrix(-0.35)


define n = Character('Narrator', color="#8f8f8f", image="narrator")


# The game starts here.

label start:

    # ==============================================================================
    # NARRATOR SPRITE REFERENCE CHEAT SHEET (`show narrator <expression>`)
    # ==============================================================================
    #
    #  awe.png         - Both arms raised/open wide, facing forward
    #  demonstrate.png - Right arm extended out presenting/gesturing outward
    #  fall.png        - Slumped stance, arms resting downward at sides
    #  fall2.png       - Slightly shifted slumped stance, head/body angled
    #  fateful.png     - Right fist raised high, assertive/dramatic gesture
    #  glory.png       - Left arm raised high pointing/reaching up
    #  pensive.png     - Standing upright, arms neutral at sides, slight head tilt
    #  ponder.png      - Head tilted slightly with hand/arm closer to chin/body
    #  still.png       - Neutral default idle stance, arms resting at sides
    #  wonder.png      - Left arm extended out to the side in a sweeping gesture
    #
    # ==============================================================================

    scene bg cave at bulb_flicker with fade
    play music "audio/blackandblue.ogg" fadein 2.0

    show narrator ponder at reset_color with fade

    pause 2.5

    show narrator still with dissolve

    pause 0.5

    n "Another come to pity me?" with dissolve
    n fall "Another come to gather, to blather and ponder?" with dissolve

    menu:
        "...what?":
            n "..." with dissolve
        "You're strange.":
            n "..." with dissolve

    n ponder "...what is so strange about me?" with dissolve

    show narrator ponder at black_and_blue with dissolve
    show bg cave at cave_dim with dissolve

    n ponder "Why am I so black and blue?" with dissolve

    show narrator wonder at reset_color with dissolve
    show bg cave at bulb_flicker with dissolve

    n wonder "When has it ever been over? All of it..." with dissolve

    n ponder "...why call it such a mystery. It's damnable as it is." with dissolve

    n awe "..." with dissolve

    n awe "...I am as invisible, as invisible as any man, should he never, can be." with fade

    n demonstrate "And I've been through many, many such things..." with dissolve
    n "Such kinds of events that...leave the man to wonder," with dissolve
    pause 1.5
    show narrator pensive with dissolve
    pause 1.5
    n pensive '{font=times.ttf}{shader=jitter}{i}"What did I do, to deserve to be so black and blue?"{/shader}{/font}{/i}' with dissolve

    # an inevitable choice
    label choice_loop:

    # Once every option has been heard, break out to the closing monologue
    # instead of falling into an empty menu.
    if choice_nothing and choice_pity and choice_peace and choice_freedom and choice_name and choice_vengeance and choice_light:
        jump choice_loop_end

    menu:
        # Each choice only appears IF its flag is still False
        "You deserve nothing." if not choice_nothing:
            $ choice_nothing = True
            $ choice_order.append("nothing")
            show narrator fall at black_and_blue with dissolve
            n fall "Nothing...?" with dissolve
            n fall2 "As if I haven't paid in blood already? Bled in a ring for White men's amusement, scrambling for fake gold on an electrified rug." with dissolve
            n pensive "My reward was a briefcase and a scholarship to a school built to keep me submissive. Everything expected of a 'good Negro.'" with dissolve
            n fall "All of it designed, from the start, to make me feel like nothing." with dissolve
            n pensive "...to {i}make me nothing.{/i} Just a 'black educated fool,' just like Dr. Bledsoe said." with dissolve
            jump choice_loop

        "You deserve pity." if not choice_pity:
            $ choice_pity = True
            $ choice_order.append("pity")
            show narrator pensive at reset_color with dissolve
            n pensive "Pity is a coin the wealthy toss down for their own sake." with dissolve
            n ponder "I watched Mr. Norton stare at that country-man Trueblood in horror..." with dissolve
            n wonder "...then hand him a hundred-dollar bill, like that was going to fix something." with dissolve
            n fall "Pity? Perhaps all he paid for was to watch a caged animal at a zoo." with dissolve
            jump choice_loop

        "You deserve peace." if not choice_peace:
            $ choice_peace = True
            $ choice_order.append("peace")
            show narrator still at reset_color with dissolve
            n still "Peace...I sought it at Liberty Paints, mixing black drops into white lead to make Optic White." with dissolve
            n fateful "When the boiler exploded, they strapped me into glass and marred my brain until I forgot my mother's name." with dissolve
            n pensive "Their 'peace' is only a quiet, Black shadow that obeys without a sound and plays 'follow the leader' until his legs fall off." with dissolve
            jump choice_loop

        "You deserve freedom." if not choice_freedom:
            $ choice_freedom = True
            $ choice_order.append("freedom")
            show narrator wonder at reset_color with dissolve
            n wonder "Freedom. Whose kind?" with dissolve
            n demonstrate "The Brotherhood gave me a microphone and audience. Then I strayed from their ideals." with dissolve
            n glory "Or Ras the Destroyer's kind, burning Harlem down for no true morality?" with dissolve
            n fall "Both wanted my body as a chess piece. That was never freedom." with dissolve
            n wonder "...and they say they freed my forefathers." with dissolve
            jump choice_loop

        "You deserve a name." if not choice_name:
            $ choice_name = True
            $ choice_order.append("name")
            show narrator ponder at reset_color with dissolve
            n ponder "A name, huh? Brother Jack handed me one, you know." with dissolve 
            n ponder "Written on a slip inside a sealed envelope." with dissolve
            n pensive '{i}"Start thinking of yourself by that name,"{/i} he said, and all would know me by that pseudonym...' with dissolve
            pause .5
            n still "...they erased what little identity I had." with dissolve
            n still "Every institution I entered, {i}stripped{/i} my name and stamped its own badge on my chest. A name given..." with dissolve
            n fall2 "...is just another leash." with dissolve
            jump choice_loop

        "You deserve vengeance." if not choice_vengeance:
            $ choice_vengeance = True
            $ choice_order.append("vengeance")
            show narrator fateful at blood_red with dissolve
            n fateful "Vengeance for who? Tod Clifton, shot down on a corner selling dancing paper puppets?" with dissolve
            n awe '{i}"Sambo, this jambo, this high-stepping joy-boy--"{/i}' with dissolve
            n fall "Blind rage only feeds the fire. It burns our own street while the ones who lit it watch from a safe distance." with dissolve
            jump choice_loop

        "You deserve light." if not choice_light:
            $ choice_light = True
            $ choice_order.append("light")
            show narrator awe at reset_color with dissolve
            n awe "Haha...I had 1,369 bulbs blazing overhead, on power I stole!" with dissolve
            n glory "My hole glowed brighter than the street above it." with dissolve
            n still "And yet none of it helped any soul see me any better." with dissolve
            n pensive "So. Visibility was never about light. It's about their refusal to look." with dissolve
            jump choice_loop

    label choice_loop_end:

    show narrator still at reset_color with dissolve
    n still "So you see... none of those words fit me." with dissolve

    # A short line that reacts to whichever word the player reached for last,
    # so the ending carries a trace of how the conversation actually went.
    if choice_order:
        $ last_choice = choice_order[-1]

        if last_choice == "nothing":
            n fall2 "Nothing, you asked last. Perhaps you were closest to being honest, hm?" with dissolve
        elif last_choice == "pity":
            n pensive "Pity, in the end...ha. You know what that gets you." with dissolve
        elif last_choice == "peace":
            n still "Considering peace...I only hope you actually mean that." with dissolve
        elif last_choice == "freedom":
            n wonder "So freedom? And where is that now?" with dissolve
        elif last_choice == "name":
            n ponder "A name, in the end. You were about to give me another one, were you?" with dissolve
        elif last_choice == "vengeance":
            n fateful "Vengeance, last of all. Consider that so carefully, whoever you are." with dissolve
        elif last_choice == "light":
            n awe "Light, at the end. Strange thing to choose, when I already have more of it than I know what to do with." with dissolve
            n fall "...why don't you look, really look, and tell me what you see?" with dissolve

    n pensive "Which is why I remain down here in my hole, drained, waiting." with dissolve
    n still "Who knows but that, on the lower frequencies, I speak for you?" with dissolve

    show narrator pensive with dissolve

    stop music fadeout 3.0
    pause .5

    n still "Go make yourself scarce, now." with fade
    n fall2 "...I hope everything you heard...was but solemn and rotten." with dissolve

    scene black with fade

    return
