
transform title_pulse:
    zoom 1.0
    linear 2.2 zoom 1.04
    linear 2.2 zoom 1.0
    repeat


transform button_glow:
    alpha 0.75
    on hover:
        linear 0.15 alpha 1.0
    on idle:
        linear 0.3 alpha 0.75

screen main_menu():

    tag menu

    # Reuses the same background and flicker as the in-story cave.
    add "bg cave" at bulb_flicker

    frame:
        style "empty"
        xalign 0.5
        yalign 0.16

        vbox:
            xalign 0.5
            spacing 6

            text "Le Invisible Man" at title_pulse:
                font "times.ttf"
                size 68
                color "#ffb066"
                outlines [(3, "#000000", 0, 0)]
                xalign 0.5

            text "{shader=jitter}monologue???? in da sewer!!?!?!{/shader}":
                font "times.ttf"
                size 24
                color "#c9a878"
                xalign 0.5

    vbox:
        xalign 0.5
        yalign 0.74
        spacing 18

        textbutton _("Start") action Start() at button_glow:
            xalign 0.5
            text_align 0.5
            text_font "times.ttf"
            text_size 34
            text_color "#e8d9c0"
            text_hover_color "#ffb066"

        textbutton _("Load") action ShowMenu("load") at button_glow:
            xalign 0.5
            text_align 0.5
            text_font "times.ttf"
            text_size 34
            text_color "#e8d9c0"
            text_hover_color "#ffb066"

        textbutton _("Preferences") action ShowMenu("preferences") at button_glow:
            xalign 0.5
            text_align 0.5
            text_font "times.ttf"
            text_size 34
            text_color "#e8d9c0"
            text_hover_color "#ffb066"

        textbutton _("About") action ShowMenu("about") at button_glow:
            xalign 0.5
            text_align 0.5
            text_font "times.ttf"
            text_size 34
            text_color "#e8d9c0"
            text_hover_color "#ffb066"

        textbutton _("Quit") action Quit(confirm=not main_menu) at button_glow:
            xalign 0.5
            text_align 0.5
            text_font "times.ttf"
            text_size 34
            text_color "#e8d9c0"
            text_hover_color "#ffb066"
